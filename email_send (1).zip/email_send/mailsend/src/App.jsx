import React from 'react'
import IssueForm from './IssueForm'

const App = () => {
  return (
    <div className="">
      <IssueForm />
    
    </div>
  )
}

export default App
