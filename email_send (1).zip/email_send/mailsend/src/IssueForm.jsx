import React, { useState } from 'react';
import axios from 'axios';
import IssueList from './IssueList';
import logo from './assets/logo.png';

const IssueForm = () => {
  const [email, setEmail] = useState('');
  const [issue, setIssue] = useState('');
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [showIssues, setShowIssues] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      const formData = new FormData();
      formData.append('email', email);
      formData.append('issue', issue);
      if (image) {
        formData.append('image', image);
      }
      console.log('FormData contents:');
      for (let pair of formData.entries()) {
        console.log(`${pair[0]}: ${pair[1]}`);
      }

      const response = await axios.post('http://localhost:3000/send-email', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      setMessage(response.data.message);
      setEmail('');
      setIssue('');
      setImage(null);
    } catch (error) {
      console.error('Error:', error);
      setMessage(error.response?.data?.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setLoginEmail('');
    setLoginPassword('');
    setShowIssues(false);
  };

  return (
    <>
      {showLoginModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-80">
            <h3 className="text-lg font-semibold mb-4 text-center">Login</h3>
            <input
              type="email"
              placeholder="Email"
              value={loginEmail}
              onChange={(e) => setLoginEmail(e.target.value)}
              className="w-full mb-2 border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <input
              type="password"
              placeholder="Password"
              value={loginPassword}
              onChange={(e) => setLoginPassword(e.target.value)}
              className="w-full mb-2 border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {loginError && <p className="text-red-500 text-sm mb-2">{loginError}</p>}
            <button
              onClick={() => {
                if (loginEmail === 'admin@softafrique.com' && loginPassword === '123456') {
                  setIsLoggedIn(true);
                  setShowLoginModal(false);
                  setLoginError('');
                } else {
                  setLoginError('Invalid email or password');
                }
              }}
              className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 transition"
            >
              Login
            </button>
            <button
              onClick={() => setShowLoginModal(false)}
              className="w-full mt-2 bg-gray-500 text-white py-2 rounded hover:bg-gray-600 transition"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between bg-[#031d42] px-8 py-2">
        <div className="flex items-center space-x-4">
          <img src={logo} alt="SOFTAFRIQUE Logo" className="w-12 h-12" />
          <div className="flex flex-col">
            <span className="text-xl font-bold text-[#267de3]">SOFTAFRIQUE</span>
            <span className="text-xs text-[#3a78a9]">GROUP OF COMPANIES</span>
          </div>
          <div>
            <span className="text-xs text-[#3a78a9]">Softafrique Support System</span>
          </div>
        </div>
        {isLoggedIn ? (
          <div className="text-white text-base cursor-pointer" onClick={handleLogout}>
            Logout
          </div>
        ) : (
          <div className="text-white text-base cursor-pointer" onClick={() => setShowLoginModal(true)}>
            Login
          </div>
        )}
      </div>

      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="max-w-2xl mx-auto mt-10 p-6 bg-white rounded-xl shadow-lg">
          {!isLoggedIn ? (
            <>
              <div className="flex justify-between whitespace-nowrap">
                <img src={logo} alt="SOFTAFRIQUE Logo" className="w-48 -mt-20" />
                <span className="text-xs font-semibold text-[#3a78a9] mt-1">
                  Softafrique Support System
                </span>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4 mt-6">
                <div>
                  <label className="block mb-1 text-gray-700">Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div>
                  <label className="block mb-1 text-gray-700">Issue</label>
                  <textarea
                    value={issue}
                    onChange={(e) => setIssue(e.target.value)}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows="4"
                    required
                  ></textarea>
                </div>

                <div>
                  <label className="block mb-1 text-gray-700">Image (optional)</label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => setImage(e.target.files[0])}
                    className="w-full border border-gray-300 rounded-md px-3 py-2"
                  />
                  {/* {image && (
                    <div className="mt-2">
                      <img
                        src={URL.createObjectURL(image)}
                        alt="Preview"
                        className="w-32 h-auto rounded"
                      />
                    </div>
                  )} */}
                </div>

                <button
                  type="submit"
                  className="w-full bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600 transition"
                  disabled={loading}
                >
                  {loading ? 'Sending...' : 'Submit'}
                </button>

                {message && <p className="mt-2 text-center text-green-600">{message}</p>}
              </form>


              {showIssues && <IssueList />}
            </>
          ) : (
            <IssueList />
          )}
        </div>
      </div>
    </>
  );
};

export default IssueForm;