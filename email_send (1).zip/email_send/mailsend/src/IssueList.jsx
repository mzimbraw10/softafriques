import React, { useEffect, useState } from 'react';
import axios from 'axios';

const IssueList = () => {
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchIssues = async () => {
      try {
        const response = await axios.get('http://localhost:3000/issues');
        setIssues(response.data);
      } catch (error) {
        console.error('Error fetching issues:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchIssues();
  }, []);

  return (
    <div className="max-w-2xl mx-auto mt-10 p-6 bg-white rounded-xl shadow-lg">
      <h2 className="text-2xl font-semibold mb-4 text-center">All Submitted Issues</h2>
      {loading ? (
        <p className="text-center">Loading...</p>
      ) : issues.length === 0 ? (
        <p className="text-center text-gray-500">No issues found.</p>
      ) : (
        <ul className="space-y-4">
          {issues.map((item) => (
            <li key={item._id} className="border border-gray-300 rounded-md p-4">
              <p className="text-gray-800"><b>Email:</b> {item.email}</p>
              <p className="text-gray-700 mt-1"><b>Issue:</b> {item.issue}</p>
              {item.image && (
                <img
                  src={item.image}
                  alt="Uploaded"
                  className="mt-3 max-h-48 object-contain border rounded"
                />
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default IssueList;
