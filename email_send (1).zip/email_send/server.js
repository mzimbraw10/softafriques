const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
app.use(bodyParser.json());
app.use(cors());

// Create Uploads folder if it doesn't exist
const uploadDir = path.join(__dirname, 'Uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/mailsend', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.error('❌ MongoDB connection error:', err));

// Schema & Model
const issueSchema = new mongoose.Schema({
  email: String,
  issue: String,
  image: String
});
const Issue = mongoose.model('Issue', issueSchema);

// Email transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'mohsinriazjmpr@gmail.com',
    pass: 'jryp wshg pjiw sqik',
  },
});

// Multer setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'Uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  }
});
const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const filetypes = /jpeg|jpg|png|gif/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);
    if (extname && mimetype) {
      cb(null, true);
    } else {
      cb(new Error('Images only (jpeg, jpg, png, gif)'));
    }
  },
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB
});

app.use('/uploads', express.static(path.join(__dirname, 'Uploads')));

// POST route: receive email, issue & image
app.post('/send-email', upload.single('image'), async (req, res) => {
  console.log('Received body:', req.body);
  console.log('Received file:', req.file);

  const { email, issue } = req.body;

  try {
    if (!email || !issue) {
      return res.status(400).json({ message: 'Email and issue are required.' });
    }

    const newIssue = new Issue({
      email,
      issue,
      image: req.file ? req.file.filename : null
    });
    await newIssue.save();
    console.log('✅ Issue saved:', newIssue);

    const mailOptions = {
      from: 'mohsinriazjmpr@gmail.com',
      to: email,
      subject: 'Your Issue Has Been Received',
      html: `<p>Thank you for reaching out.</p><p><b>Your Issue:</b> ${issue}</p>${
        req.file ? '<p><b>Image:</b> <img src="cid:image1" alt="Uploaded Image" style="max-width: 300px;"></p>' : ''
      }`,
      attachments: req.file ? [{
        filename: req.file.filename,
        path: path.join(__dirname, 'Uploads', req.file.filename),
        cid: 'image1' // Content-ID for inlining
      }] : []
    };
    await transporter.sendMail(mailOptions);
    console.log('✅ Confirmation email sent');

    setTimeout(async () => {
      try {
        const followUpOptions = {
          from: 'mohsinriazjmpr@gmail.com',
          to: email,
          subject: 'Follow-up on your issue',
          html: `<p>Your issue has been received successfully. We will get back to you soon.</p>`,
        };
        await transporter.sendMail(followUpOptions);
        console.log('✅ Follow-up email sent');
      } catch (followUpError) {
        console.error('❌ Error sending follow-up email:', followUpError);
      }
    }, 20000);

    res.status(200).json({ message: 'Issue saved and confirmation email sent.' });
  } catch (error) {
    console.error('❌ Error:', error);
    res.status(500).json({ message: error.message || 'Something went wrong' });
  }
});

// GET route: fetch all issues
app.get('/issues', async (req, res) => {
  try {
    const issues = await Issue.find().sort({ _id: -1 });
    const updatedIssues = issues.map(issue => ({
      _id: issue._id,
      email: issue.email,
      issue: issue.issue,
      image: issue.image ? `http://localhost:3000/uploads/${issue.image}` : null
    }));
    res.json(updatedIssues);
  } catch (error) {
    console.error('❌ Error fetching issues:', error);
    res.status(500).json({ message: 'Failed to fetch issues' });
  }
});

// Start server
app.listen(3000, () => {
  console.log('🚀 Server running on http://localhost:3000');
});